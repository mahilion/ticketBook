package com.mahi.DAO;

import com.mahi.Model.User;

import java.util.List;

/**
 * Created by mahesh on 8/4/16.
 */

//ALL database methods are listed here
public interface UserDAO {
    public String insertUser(User u);
    public User getUser(int id);
    public User getUser(String name);
    public String updateUser(User u);
    public String deleteUser(User u);
    public List<User> getAllUser();

}
