package com.mahi.DAO;

import com.mahi.Model.User;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by mahesh on 8/4/16.
 */
@Repository("UserDao")
public class UserDAOImpl implements UserDAO {

    @Autowired
    private SessionFactory sessionFactory;

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    @Transactional
    public String insertUser(User u) {
        // inserts into database & return userId (primary_key)
        int Id = (Integer) sessionFactory.getCurrentSession().save(u);
        return "user information saved , id is " + Id;
    }

    @Override
    @Transactional
    public User getUser(int id) {
        // retrieve customer based on the id supplied in the formal argument
        User u = (User) sessionFactory.getCurrentSession().get(User.class,id);
        return u;
    }

    @Override
    @Transactional
    public User getUser(String name) {
        User u= (User) sessionFactory.getCurrentSession().get(User.class,name);
        return u;
    }

    @Override
    @Transactional
    public String updateUser(User u) {
        // update database with customer information and return success msg
        sessionFactory.getCurrentSession().update(u);
        return "user info updated";
    }

    @Override
    @Transactional
    public String deleteUser(User u) {
        sessionFactory.getCurrentSession().delete(u);
        return "user info deleted";
    }

    @Override
    @Transactional
    public List<User> getAllUser() {
        // get all User info from database
        List<User> u = sessionFactory.getCurrentSession().createCriteria(User.class).list();
        return u;
    }
}
