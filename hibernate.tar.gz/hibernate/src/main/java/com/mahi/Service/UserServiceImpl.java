package com.mahi.Service;

import com.mahi.DAO.UserDAO;
import com.mahi.Model.User;

import com.mahi.Model.UserType;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;


import javax.ws.rs.PathParam;
import java.util.List;

/**
 * Created by mahesh on 8/4/16.
 */
@Controller
public class UserServiceImpl implements UserService{

    @Autowired
    UserDAO userDAO;

    @Override
    public String addUserToDatabase(UserType u) {
        User u1=new User();
        u1.setUserID((u.getUserID()));
        u1.setName(u.getName());
        u1.setEmail(u.getEmail());
        u1.setPassword(u.getPassword());
        u1.setPhone(u.getPhone());
        return userDAO.insertUser(u1);
    }

    @Override
    public User getUserById(@PathParam("id") int id) {
        User u1= userDAO.getUser(id);
        return u1;
    }

    @Override
    public List<User> getUsersFromDAtabase() {
        List<User> u1=userDAO.getAllUser();
        return u1;

    }

    @Override
    public String authUser() {
        User u1=new User();

        u1=userDAO.getUser(n);

        if(u1.getPassword())





        return null;
    }


}
