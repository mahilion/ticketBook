package com.mahi.Service;

import com.mahi.Model.User;
import com.mahi.Model.UserType;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;
/**
 * Created by mahesh on 8/4/16.
 */
@Path("/rest/userservice")
public interface UserService {

    @POST
    @Path("/adduser")
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_FORM_URLENCODED})
    @Consumes(MediaType.APPLICATION_JSON)
    public String addUserToDatabase(UserType u);

    @GET
    @Path("/getusers/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public User getUserById(@PathParam("id")int id);

    @GET
    @Path("/getusers")
    @Produces(MediaType.APPLICATION_JSON)
    public List<User> getUsersFromDAtabase();

    @GET
    @Path("/login/{name}")
    @Produces(MediaType.APPLICATION_FORM_URLENCODED)
    @Consumes(MediaType.APPLICATION_JSON)
    public String authUser(@PathParam("name")String n,@PathParam("pass")String p);

}
