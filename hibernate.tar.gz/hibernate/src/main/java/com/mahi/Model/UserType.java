package com.mahi.Model;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by mahesh on 8/4/16.
 */
@XmlRootElement
public class UserType {

    private int userID;
    private String name;
    private String email;
    private long phone;
    private String password;

    public UserType()
    {
        super();
    }

    public UserType(int userID, String name, String email, long phone, String password) {
        this.userID = userID;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.password = password;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public long getPhone() {
        return phone;
    }

    public void setPhone(long phone) {
        this.phone = phone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    protected List<UserType> listme;
    public List<UserType> getlist()
    {
        if(listme==null ){
            listme=new ArrayList<UserType>();
        }
        return this.listme;
    }

    @Override
    public String toString() {
        return "UserType{" +
                "userID=" + userID +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", phone=" + phone +
                ", password='" + password + '\'' +
                '}';
    }
}
